#Hola! Somos el grupo New Tech (conformado por Guillermina Cassini, Nico Crespo y Alejo Leiva) de la Escuela Normal Mixta a continuacion tienen nuestro codigo espero que lo disfruten.
  
#Cargamos las librerÃ­as necesarias
import turtle
import random
import math

#Se realizan funciones de apoyo para que el main.py con nombres bien representativos
#Definimos los elementos dinamicos  que utilizaremos durante el juego.
def dibujarElementosDinamicos(basura, jugador, cronometro, tiempoActual, puntuador, puntosActuales, modoDeJuego):
  
  if tiempoActual > 0:
    cronometro.write(tiempoActual, font=("Arial", 16, "bold"))
  if puntosActuales > 0:
    puntuador.write(puntosActuales, font=("Arial", 16, "bold"))
    
  basura.showturtle()
  jugador.showturtle()  
 
#Definimos el movimiento de la basura utilizando los patrones de movimiento.
def moverBasura(basura, patronMovimiento):
  basura.penup()
  
  if (patronMovimiento=='linea'):
    basura.forward(0.7)
 
  if (patronMovimiento=='aleatorio'):
    basura.right(random.randint(-180,180))
    basura.forward(25)
    basura.setx(basura.xcor()+random.randint(-20,20))
    basura.sety(basura.ycor()+random.randint(-20,20))
 
  return basura

#Definimos la basura que utilizaremos en cada modo de juego.
def obtenerBasura(desechos):
  if desechos == 'inorganicos':#Basura para los modos porPuntos y porTiempo.
    imgs = ["organico.gif", "vidrio.gif","lata.gif", "otros.gif", "papel.gif", "toxico.gif"]
    imgActual=random.choice(imgs)  
    basura = turtle.Turtle()
    basura.hideturtle()
    basura.shape(imgActual)
    basura.penup()
    basura.goto(random.randint(-180,180),random.randint(-180,180))

  else:
    imgs2 = ["organico.gif", "lechuga.gif", "manzana.gif"]#Basura para el modo organico.
    imgActual=random.choice(imgs2)
    basura = turtle.Turtle()
    basura.hideturtle()
    basura.shape(imgActual)
    basura.penup()
    basura.goto(random.randint(-180,180),random.randint(-180,180))

  return basura


def obtenerObstaculo(jugador):
  
  posicionX=random.randint(-180,180)
  posicionY=random.randint(-180,180)
  obstaculo=turtle.Turtle()
  
  obstaculo.penup()
  obstaculo.shape("piedra.gif")
  obstaculo.goto(posicionX,posicionY)

  x = obstaculo.xcor()
  y = obstaculo.ycor()

  if jugador.ycor() <(y-25):
    jugador.sety(y-100)
  elif jugador.ycor()>(y+25):
    jugador.sety(y+100)
  if jugador.xcor()<(x-25):
    jugador.setx(x-100)
  elif jugador.xcor()>(x+25):
    jugador.setx(x+100)
#  posicionBarrera
 # mano=turtle.Turtle()
  #mano.goto(posicionBarrera)

  
#Definimos al jugador.
def obtenerJugador():
  jugador=turtle.Turtle()
  jugador.shape("robot.gif")
  jugador.penup()
  jugador.setx(-20)
  jugador.sety(-80)
  return jugador

#Definimos el cronometro.
def obtenerCronometro():
  tiempoRestante=turtle.Turtle()
  tiempoRestante.penup()
  tiempoRestante.hideturtle()
  tiempoRestante.setx(150)
  tiempoRestante.sety(260)
  
  return tiempoRestante

#Definimos el puntaje. 
def obtenerPuntuador():
  puntuador=turtle.Turtle()
  puntuador.penup()
  puntuador.hideturtle()
  puntuador.setx(-80)
  puntuador.sety(260)
  
  return puntuador

#Definimos el texto que utilizaremos para mostrar el tiempo.
def obtenerTxtTiempoRestante():
  txtTiempoRestante=turtle.Turtle()
  txtTiempoRestante.penup()
  txtTiempoRestante.hideturtle()
  txtTiempoRestante.setx(30)
  txtTiempoRestante.sety(260)
  return txtTiempoRestante 

#Definimos el texto que utilizaremos para mostrar los puntos.  
def obtenerTxtPuntos():
  txtPuntos=turtle.Turtle()
  txtPuntos.penup()
  txtPuntos.hideturtle()
  txtPuntos.setx(-190)
  txtPuntos.sety(260)
  return txtPuntos   

#Definimos la barrera para la basura si se sale de los limites.
def reubicarBasuraSiSeVa(bas):
    x = bas.xcor()
    y = bas.ycor()
    
    if x > 200:
      bas.setx(200)
    elif x < -200:
      bas.setx(-200)
    if y > 200:
      bas.sety(200)
    elif y < -200:
      bas.sety(-200)
    return bas

#Definimos la barrera para el jugador si se sale de los limites.
def reubicarJugadorSiSeVa(jug):
    x = jug.xcor()
    y = jug.ycor()
    
    if x > 200:
      jug.setx(200)
    elif x < -200:
      jug.setx(-200)
  
    if y > 200:
      jug.sety(200)
    elif y < -200:
      jug.sety(-200)
    return jug

#Definimimos la zona Prohibida donde se recolecta la basura
def zonaPeligrosa(jug):
  devolucion=True
  y=jug.ycor()
  if y>130:
    devolucion=True
  else:
    devolución=False
  if y<-135:
    devolucion=True
  else:
    devolucion=False
  return devolucion


#Definimos la distancia que puede haber entre el jugador y la basura.
def colisionan(obj, jugador, umbral):
  d=math.sqrt(math.pow(obj.xcor()-jugador.xcor(),2)+math.pow(obj.ycor()-jugador.ycor(),2))
  if d < umbral:
    return True
  else:
    return False

#Definimos la funcion que se encargara de guardar los datos de los jugadores.
def guardarDatos(Jugador, modoJuego, Valor):
  fila = Jugador + "   ::   " + modoJuego + "   ::   " + str(Valor) + "\n"
  tabla = open("tabla.txt", "a")
  tabla.write(fila)
  tabla.close()

#Definimos la funcion que se encarga de mostrar el mensaje de "Buen Trabajo!!".
def mostrarMensaje(txtMensajes): 
    txtMensajes.penup()
    txtMensajes.color("green")
    txtMensajes.goto(-10,-281)
    txtMensajes.write("Buen Trabajo!!", font=("Comic Sans MS", 22, "bold"))
    
#Definimos la funcion que se encarga de ocultar el mensaje de "Buen Trabajo!!" despues de que pasen 3 segundos.
def ocultarMensaje(txtMensajes):
  txtMensajes.clear()

#Esta función sirve para saber si el tipo de basura recolectada (o colisionada) es reciclable.
def esReciclable(bas):
  if str(bas.shape()) == 'vidrio.gif' or str(bas.shape()) == 'papel.gif' or str(bas.shape()) == 'lata.gif':
    return True
  else:
    return False



def leerArchivo (listaNombres,listaPuntaje,modo):
  nombreArchivo = modo + '.txt'
  archivo=open(nombreArchivo,'r')

  for line in archivo: 
    linea=line.split('-')
    listaNombres.append(linea[0])
    listaPuntaje.append(int(linea[1]))

  archivo.close()


def insertar_ordenado(puntaje,listaPuntaje,nombre,listaNombres):
    auxP=0
    auxN=''

    for indice in range (len(listaPuntaje)):

        if (puntaje > listaPuntaje[indice]):
            auxP=listaPuntaje[indice]
            auxN=listaNombres[indice]
            listaPuntaje[indice]=puntaje
            listaNombres[indice]=nombre
            puntaje=auxP
            nombre=auxN

    listaPuntaje.append(puntaje)
    listaNombres.append(nombre)

def insertar_ordenado_tiempo(tiempo,listaTiempo,nombre,listaNombres):
    auxT=0
    auxN=''

    for indice in range (len(listaTiempo)):

        if (tiempo < listaTiempo[indice]):
            auxT=listaTiempo[indice]
            auxN=listaNombres[indice]
            listaTiempo[indice]=tiempo
            listaNombres[indice]=nombre
            tiempo=auxT
            nombre=auxN

    listaTiempo.append(tiempo)
    listaNombres.append(nombre)


def escribirArchivo (listaNombres,listaValor,modo):
  nombreArchivo = modo + '.txt'   ## ---->>> Creamos el nombre del archivo donde se van a guardar los datos

  archivo=open(nombreArchivo,'w')
  cadena=''

  for indice in range(len(listaValor)):
      cadena= cadena + listaNombres[indice]+'-'+str(listaValor[indice])+'\n'

  archivo.write(cadena)
  archivo.close()



def crearRanking(listaNombres,listaValor,nombre,valor,modo):
  leerArchivo(listaNombres,listaValor,modo)
  if(modo == 'porTiempo'):              ###--------->> Si el modo es 'porTiempo' llama a una funcion de ordenar y si no, llama a otra
    insertar_ordenado(valor,listaValor,nombre,listaNombres)
  else:
     insertar_ordenado_tiempo(valor,listaValor,nombre,listaNombres)
  escribirArchivo(listaNombres,listaValor,modo)

def escribirPuntajes(txtInstrucciones):
  listaPuntaje=[]
  listaNombre=[]
  posicionY=-150
  #Posicionamos la tortuga y escribimos el titulo en Azul
  txtInstrucciones.color("blue")
  txtInstrucciones.goto(-300,posicionY)
  txtInstrucciones.write("Mejores Puntajes", font=("Comic Sans MS", 18, "bold"))
  txtInstrucciones.color("black")
  leerArchivo(listaNombre,listaPuntaje,'porTiempo') # Leemos el archivo 'porPuntos' y llenamos las listas
  
  for indice in range(len(listaPuntaje)):
    posicionY = posicionY - 20
    txtInstrucciones.goto(-300,posicionY)  #Posicionamos la tortuga para escribir los records
    #Escribimos los mejores puntos, de la forma "Jugador: ' ' - Pts: ' '" por cada posicion de las listas
    i=0
    if (i<5):
      txtInstrucciones.write('Jugador: '+listaNombre[indice]+ ' - Pts: '+str(listaPuntaje[indice]),  font=("Courier", 12, "bold"))
    i=i+1


def escribirTiempos(txtInstrucciones):
  listaTiempo=[]
  listaNombre=[]
  posicionY=-150
  posicionX=50
  #Posicionamos la tortuga y escribimos el titulo en Azul
  txtInstrucciones.color("blue")
  txtInstrucciones.goto(posicionX,posicionY)
  txtInstrucciones.write("Mejores Tiempos", font=("Comic Sans MS", 18, "bold"))
  txtInstrucciones.color("black")
  leerArchivo(listaNombre,listaTiempo,'porPuntos') # Leemos el archivo 'porPuntos' y llenamos las listas
  
  for indice in range(len(listaTiempo)): 
      posicionY = posicionY - 20
      i=0
      if(i<5):
        txtInstrucciones.goto(posicionX,posicionY) #Posicionamos la tortuga para escribir los records
      #Escribimos los mejores tiempos, de la forma "Jugador: ' ' - Seg: ' '" por cada posicion de las listas
        txtInstrucciones.write('Jugador: '+listaNombre[indice]+ ' - Seg: '+str(listaTiempo[indice]),  font=("Courier", 12, "bold"))
      i=i+1


#Les agradecemos por leer nuestro codigo.
#Un saludo de parte de Guille, Nico y Mano_De_Programador.
