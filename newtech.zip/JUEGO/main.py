#Hola! Somos el grupo New Tech (conformado por Guillermina Cassini, Nico Crespo y Alejo Leiva) de la Escuela Normal Mixta a continuacion tienen nuestro codigo espero que lo disfruten.

#Cargamos las librerias necesarias.
import turtle
from funciones import *
import time


#Cargamos los recursos de imagenes. Primero se deben subir y activar a Trinket.
screen = turtle.Screen()
screen.register_shape("organico.gif")
screen.register_shape("vidrio.gif")
screen.register_shape("lata.gif")
screen.register_shape("otros.gif")
screen.register_shape("papel.gif")
screen.register_shape("toxico.gif")
screen.register_shape("robot.gif")
screen.register_shape("lechuga.gif")
screen.register_shape("manzana.gif")
screen.register_shape("piedra.gif")




#Inicializamos variables y aclaramos variables globales.
puedoConfigurar=True
jugando = False
situada = False
patronMovimiento='aleatorio'  
modoDeJuego='porTiempo'

global txtInstrucciones, txtMensajes
tiempoTotalConfigurado=30
puntosTotalesConfigurados=1000
nombreJugador='Jug1'
tiempoTotal=tiempoTotalConfigurado
puntosTotales=puntosTotalesConfigurados
tiempoActual=0
puntosActuales=0
juegoOrganico=False
tiempoColision=0
tiempoHoy=0
tiempoFinJuego=0
desechos = ''

listaValor=[]         #<<------|| Cambiamos el nombre de la lista
listaNombres=[] 
archivo=open("porTiempo.txt",'a')  ##Abrimos y cerramos los archivo con 'a' para que se creen,sino estan creados
archivo.close()
archivo=open("porPuntos.txt",'a')
archivo.close()
#Introducimos el diccionario con los puntajes de la basura
diccionarioPuntaje = {"organico.gif" : "200", "otros.gif" : "10", "toxico.gif" : "150", "vidrio.gif" : "75", "lata.gif" : "50", "papel.gif" : "30" , "lechuga.gif" : "200", "manzana.gif" : "200"}

#Definimos la funcion mostrarMenu en donde configuramos el fondo y el menu.
def mostrarMenu():
  global txtInstrucciones, puedoConfigurar
  screen.bgpic("")
  #Configuramos la tortuga que se encargara de mostrar el menu.
  txtInstrucciones = turtle.Turtle()
  txtInstrucciones.hideturtle()
  txtInstrucciones.speed(0)
  txtInstrucciones.penup()
  
  txtInstrucciones.color("red")
  txtInstrucciones.setx(-120)
  txtInstrucciones.sety(220)
  txtInstrucciones.write("Reciclemos Juntos",  font=("Comic Sans MS", 24, "bold"))
  
  txtInstrucciones.goto(-300,160)
  txtInstrucciones.color("blue")
  txtInstrucciones.write("Instrucciones", font=("Comic Sans MS", 18, "bold"))
  txtInstrucciones.goto(-300,140)
  txtInstrucciones.color("black")  
  txtInstrucciones.write("Mueve el robot con las flechas para recolectar los residuos", font=("Courier", 12, "bold"))

  txtInstrucciones.color("blue")
  txtInstrucciones.goto(-30,80)
  txtInstrucciones.write("Menu", font=("Comic Sans MS", 18, "bold"))
  txtInstrucciones.goto(-300,50)
  txtInstrucciones.color("black")
  txtInstrucciones.write("t - Empezar juego por tiempo", font=("Courier", 12, "bold"))
  txtInstrucciones.goto(-300,20)
  txtInstrucciones.write("p - Empezar juego por puntos", font=("Courier", 12, "bold"))
  txtInstrucciones.goto(-300,-10)
  txtInstrucciones.write("o - Empezar modo organico", font=("Courier", 12, "bold"))
  
  txtInstrucciones.goto(30,30)
  txtInstrucciones.write("q - Salir del juego y volver \n \t al menu", font=("Courier", 12, "bold"))
  txtInstrucciones.goto(30,0)
  txtInstrucciones.write("c - Configuracion del juego", font=("Courier", 12, "bold"))

  escribirPuntajes(txtInstrucciones)     ##Llamamos a la función escribirPuntajes y le pasamos la 'tortuga'
                                         ##para que escriba,en el menu, los mejores puntajes del modo 'porTiempo'

  escribirTiempos(txtInstrucciones)      ##Llamamos a la función escribirTiempos y le pasamos la 'tortuga'
                                         ##para que escriba,en el menu, los mejores tiempos del modo 'porPuntos'

  puedoConfigurar = True
  screen.update()

mostrarMenu()
 
jugador=obtenerJugador()

#Definimos al bucle del juego
def loopJuego():
#Definimos las globales que utilizaremos durante el bucle del juego.
  global jugando, txtInstrucciones, situada, jugador, patronMovimiento, puedoConfigurar, modoDeJuego,obstaculo, tiempoTotal, puntosTotales, puntosActuales, nombreJugador, juegoOrganico, mostrarMensaje, borrarMensaje, txtMensajes, tiempoColision, nombreJugador, tiempoFinJuego,desechos,listaValor,listaNombres
  

#Definimos la tortuga "txtMensaje" la cual utlizaremos para hacer que aparezca el cartel de Buen Trabajo!!
  txtMensajes=turtle.Turtle() 
  txtMensajes.hideturtle()
  txtInstrucciones.clear()#Limpiamos las instrucciones para que no aparezcan durante el juego.
  screen = turtle.Screen()
  ventana = turtle.Screen()
  nombreJugador = ventana.textinput("ID", "Ingresá  tu ID de juego: ")
  screen.listen()
  screen.bgpic("fondo-1.gif")
  
  cronometro=obtenerCronometro()
  puntuador=obtenerPuntuador()

  #Escribimos el tiempo y el puntaje durante el juego.
  txtTiempoRestante=obtenerTxtTiempoRestante()
  txtTiempoRestante.color("black")
  txtTiempoRestante.write('Tiempo: ', font=("Courier", 18, "bold"))
  txtPuntos=obtenerTxtPuntos()
  txtPuntos.color("black")
  txtPuntos.write('Puntos: ', font=("Courier", 18, "bold"))
  
  tiempoInicio=int(round(time.time()))
  
  auxTiempo=int(round(time.time()-tiempoInicio))
  auxPuntos=0

  obstaculo=obtenerObstaculo(jugador)
  
  #Introducimos el modo porTiempo y el modo porPuntos.
  if (modoDeJuego=='porTiempo'):
    puntosActuales=0
    tiempoRestante=tiempoTotalConfigurado
  elif (modoDeJuego=='porPuntos'):
    puntosActuales=puntosTotalesConfigurados
    puntosRestantes=0
    tiempoRestante=0

 #Desarrollamos las basuras para el modo organico.
  if(juegoOrganico==True):
    bas=obtenerBasura(desechos)

#Desarrollamos las basuras para el resto de modos de juego.
  else:
    bas=obtenerBasura(desechos)
  
  #Introducimos el while del juego.
  while (jugando == True):

  
    puedoConfigurar=False
    tiempoRestante=int(round(time.time()-tiempoInicio))#Introducimos variantes de tiempo y desarrollamos el tiempo y el puntaje de los 2 modos de juego.
    if (modoDeJuego=='porTiempo'):
      
    
      if not (tiempoRestante==auxTiempo):
        cronometro.clear()
        auxTiempo = tiempoRestante
    
      tiempoRestante=tiempoTotal-tiempoRestante
    
    elif (modoDeJuego=='porPuntos'):
      if not (tiempoRestante==auxTiempo):
        cronometro.clear()
        auxTiempo = tiempoRestante
      
      auxPuntos = puntosRestantes
    
  #Definimos el diccionario de patrones y se las asignamos a la basura.
    patrones=['linea', 'aleatorio']
    bas=moverBasura(bas, patronMovimiento)
    
    if (situada==False):
      patronMovimiento=random.choice(patrones)
      situada=True      
    
    bas=moverBasura(bas, patronMovimiento)

    #Desarrollamos los limites para el jugador y la basura.
    bas=reubicarBasuraSiSeVa(bas)
    jugador=reubicarJugadorSiSeVa(jugador)
    
    num=int(diccionarioPuntaje[bas.shape()])
    tiempoHoy=time.time()

    if (colisionan(jugador, bas, 60) == True):

      #Hacemos aparecer el mensaje de Buen Trabajo!!
      if esReciclable(bas):
        mostrarMensaje(txtMensajes)
        tiempoColision = tiempoHoy

  
      situada = False
      bas.hideturtle()
      bas.clear()

       #Introducimos la basura que utilizaremos en el modo organico.
      if(juegoOrganico == True): 
        bas=obtenerBasura(desechos)  
      else:
       #Introducimos la basura que utilizaremos en los otros dos modos de juego. 
        bas=obtenerBasura(desechos)
        
      if(modoDeJuego=='porPuntos'):
        # Verificamos que la basura recogida sea en Zona Permitida
        zona=zonaPeligrosa(jugador)
        if(zona==False):
          puntosActuales=puntosActuales-num
        
        if (puntosActuales<=0):
          #Guardo los datos del modo porPuntos.
          tiempoFinJuego=int(round(time.time()-tiempoInicio))
          guardarDatos(nombreJugador, modoDeJuego, tiempoFinJuego)
         
##********************************************************************************************************************************************************##
          crearRanking(listaNombres,listaValor,nombreJugador,tiempoFinJuego, modoDeJuego) #---> Llamamos a la funcion crearRanking para que nos llene el archivo .txt
          listaNombres=[]   #----> Limpiamos la lista de Nombres                ^
          listaValor=[]   #----> Limpiamos la lista de Puntos                   |__ Agregamos el parametro 'modoDeJuego' para formar el nombre del archivo (mirar la definicion de la funcion!!)
##********************************************************************************************************************************************************##

          
          #Borramos el cronometro y la puntuacion cuando termine el juego.
          cronometro.clear()
          puntuador.clear()
          jugando=False
          
          
      else:
        zona=zonaPeligrosa(jugador)
        if(zona==False):
          puntosActuales=puntosActuales+num
      
      
      if not (puntosActuales==auxPuntos):
        puntuador.clear()
        auxPuntos=puntosActuales
        
      
    tiempoHoy=time.time()
    if (tiempoHoy - tiempoColision) >= 3:
      #Ocultamos el mensaje despues de que pasen 3 segundos.
      ocultarMensaje(txtMensajes)
      tiempoColision=tiempoHoy

      
    if (modoDeJuego=='porTiempo'):  
     if (tiempoRestante<=0):
        #Guardo los datos del modo porTiempo.
        guardarDatos(nombreJugador, modoDeJuego, puntosActuales)
        
##********************************************************************************************************************************************************##
        crearRanking(listaNombres,listaValor,nombreJugador,puntosActuales, modoDeJuego) #---> Llamamos a la funcion crearRanking para que nos llene el archivo .txt
        listaNombres=[]   #----> Limpiamos la lista de Nombres                ^
        listaValor=[]   #----> Limpiamos la lista de Puntos                   |__ Agregamos el parametro 'modoDeJuego' para formar el nombre del archivo (mirar la definicion de la funcion!!)
##********************************************************************************************************************************************************##

        cronometro.clear()#Y limpiamos el cronometro del juego cuando termine.
        jugando=False

    dibujarElementosDinamicos(bas, jugador, cronometro, tiempoRestante, puntuador, puntosActuales, modoDeJuego)
    screen.update()

  
  #Si el juego esta detenido borramos todos los elementos jugables y mostramos el menu.
    
  jugador.hideturtle()
  jugador.clear()
  obstaculo.hideturtle()
  obstaculo.clear()
  txtTiempoRestante.clear()
  txtTiempoRestante.hideturtle()
  txtPuntos.clear()
  txtPuntos.hideturtle()
  puntuador.clear()
  puntuador.hideturtle()
  cronometro.clear()
  cronometro.hideturtle()
  bas.hideturtle()
  bas.clear()
  ocultarMensaje(txtMensajes)
  txtInstrucciones.hideturtle()
  txtInstrucciones.clear()
    
  mostrarMenu()
    
#Definimos la operacion de comienzo de juego
def empezarJuego():
  global jugando, puedoConfigurar#Definimos las globales.
  if (jugando==False):
    jugando = True
    loopJuego()

#Definimos la operacion de comienzo del modo porPuntos.   
def empezarJuegoPorPuntos():
  global modoDeJuego, desechos
  modoDeJuego='porPuntos'
  desechos = 'inorganicos'
  empezarJuego()

#Definimos la operacion de comienzo del modo Organico. 
def empezarJuegoOrganico():
  global juegoOrganico, desechos
  desechos = 'organicos'
  juegoOrganico=True
  modoDeJuego='porPuntos'
  empezarJuego()

#Definimos la operacion de comienzo del modo porTiempo. 
def empezarJuegoPorTiempo():
  global modoDeJuego, desechos
  modoDeJuego='porTiempo'
  desechos = 'inorganicos'
  empezarJuego()

#Definimos la operacion para volver al menu. 
def volverAlMenu():
  global jugando, puedoConfigurar
  jugando = False
  puedoConfigurar=False
  desechos=''

#Definimos la operacion para ingresar los parametros de configuracion. 
def ingresarParametrosDeConfiguracion():
  global tiempoTotal, puntosTotalesConfigurados, puedoConfigurar, jugando, nombreJugador
  
  if (jugando==False):
    #Desarrollamos la configuracion para el juego.
    if (puedoConfigurar==True):
      puedoConfigurar=False
      tiempoTotal= int(input("Ingrese la cantidad de segundos que dispondra¡ el jugador para el Modo por Tiempo:"))
      puntosTotalesConfigurados= int(input("Ingrese el puntaje maximo para el Modo Puntos:"))
      
      if not (tiempoTotal > 0):
        tiempoTotal=10
      if not (puntosTotalesConfigurados > 0):
        puntosTotalesConfigurados=5
   
      
#Definimos las funciones de movimiento del jugador.
def atras():
  global jugador
  jugador.sety(jugador.ycor()-40)

def adelante():
  global jugador
  jugador.sety(jugador.ycor()+40)

def izquierda():
    global jugador
    jugador.setx(jugador.xcor()-40)

def derecha():
    global jugador
    jugador.setx(jugador.xcor()+40)

#Y la funcion para salir del juego.
def salirDelJuego():
  global jugando, desechos
  desechos = ''
  jugando=False  

#Realizamos codigo que invoca las funciones anteriores segun la tecla que se presione  

turtle.onkey(adelante, "Up")
turtle.onkey(atras, "Down")
turtle.onkey(izquierda, "Left")
turtle.onkey(derecha, "Right")
turtle.onkey(empezarJuegoPorPuntos, "p")
turtle.onkey(empezarJuegoPorTiempo, "t")
turtle.onkey(empezarJuegoOrganico, "o")
turtle.onkey(ingresarParametrosDeConfiguracion, "c")
turtle.onkey(salirDelJuego, "q")
#Hacemos que Python escuche al teclado.
turtle.listen()
turtle.mainloop()


#Les agradecemos por leer nuestro codigo.
#Un saludo de parte de Guille, Nico y Mano_De_Programador.
