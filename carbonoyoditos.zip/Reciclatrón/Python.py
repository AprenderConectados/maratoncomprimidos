#Bienvenidos a nuestro juego! reprogramamos el codigo entero a la libreria pygame. Creemos que esta nos proporcionara mucha mas flexibilidad a la hora de programar.
##
##
##
##
#aca importamos las librerias de vamos a usar a lo largo del codigo
import pygame
from io import open
import time
import math
from random import *
import os.path

##  Creamos una clase para las zonas peligrosas, y las zonas de bonificacion. A esta le damos todas las propiedades necesarias.
class Zona:
    
    existe = False
    tamano =  randint(200, 300)
    posx = randint(91, 1100-tamano)
    posy = randint(77, 570-tamano)
    tiempo = time.time()
    duracion = 1#randint(4, 7)
    borde = None
    
    def desaparece(self):
        self.existe = False
    def devuelve_existe(self):
        return self.existe
    def devuelve_posx(self):
        return self.posx
    def devuelve_posy(self):
        return self.posy
    def devuelve_tamao(self):
        return self.tamano
    def devuelve_tiempo(self):
        return self.tiempo
    def devuelve_duracion(self):
        return self.duracion
    def verificaTiempo(self):
        a = True
        if time.time() - self.tiempo <= self.duracion:
            a = False
        return a
    def devuelve_borde(self):
        return self.borde
    def colision_con_robotin(self, x, y):
        a = x+16
        b = y+16
        c = False
        if a>self.posx and a<self.posx+self.tamano and b>self.posy and b<self.posy+self.tamano:
            c = True
        return c
    def set(self):
        self.existe = True
        self.tamano = randint(200, 300)
        self.posx = randint(91, 1100-self.tamano)
        self.posy = randint(77, 570-self.tamano)
        self.tiempo = time.time()
        self.duracion = randint(4, 7)
        self.borde = pygame.Rect(self.posx,self.posy,self.tamano,self.tamano)
    def colision_con_charco(self, x, y):
        c = False
        if x+128>self.posx and x<self.posx+self.tamano and y+128>self.posy and y<self.posy+self.tamano:
            c = True
        return c
    def  hay_colision_con_charcoxmas(self, x):
        a = False
        if x+128>self.posx:
            a = True
        return a            
    def  hay_colision_con_charcoxmenos(self, x):
        a = False
        if x < self.tamano+self.posx:
            a = True
        return a            
    def  hay_colision_con_charcoymas(self, y):
        a = False
        if y+128>self.posy:
            a = True
        return a
    def  hay_colision_con_charcoymenos(self, y):
        a = False
        if y<self.tamano+self.posy:
            a = True
        return a
    def ajustes_charco(self, x, y):
        self.existe = True
        self.tamano = 256
        a = randint(91, 844)
        b = randint(77, 314)
##        while self.colision_con_charco(a, b):
##            a = randint(91, 844)
##            b = randint(77, 314)
        a = self.posx
####        while b+256<y or b > y+128:
##            
####            print(b)
        b = self.posy
        self.duracion = randint(4, 7)
        self.tiempo = time.time()
        

#aca definimos unos colores
black = (0, 0, 0)
white = (255, 255, 255)
gris = (115, 115, 115)
rojo = (255, 0, 0)
verde = (0,120,0)

#definimos el tamañano de la pantalla
display_width = 1358
display_height = 750

#iniciamos los modulos de pygame
pygame.init()



#le ponemos el nombre del juego a la ventana
pygame.display.set_caption("Reciclatron")





#creamos la pantalla y lo que requiere
pantalla = pygame.display.set_mode((display_width, display_height), pygame.FULLSCREEN)
reloj = pygame.time.Clock()
pygame.display.update()
reloj.tick(60)

#cargamos archivos externos
archivosRecords = ["Records Puntos.txt", "Records Tiempo.txt", "Records Puntos (Organico).txt", "Records Tiempo (Organico).txt"]
background = pygame.image.load("background.png")
fondoMenu = pygame.image.load("fondo rayas.png")
robotin1 = pygame.image.load("robotin.png")
robotin2 = pygame.image.load("robotin2.png")
robotin3 = pygame.image.load("robotin3.png")
robotin4 = pygame.image.load("robotin4.png")
robotin5 = pygame.image.load("robotin5.png")
charco_imagen = pygame.image.load("charco.png")
lata = pygame.image.load("lata.gif")
organico = pygame.image.load("organico.gif")
papel = pygame.image.load("papel.gif")
toxico = pygame.image.load("toxico.gif")
vidrio = pygame.image.load("vidrio.gif")
otros = pygame.image.load("otros.gif")
audio_menu = pygame.mixer.music.load("Undertale OST_ 043 - Temmie Village.ogg")


#definimos las palabras motivadoras cuando se agarra un reciclable
felicitacion = ["Buen trabajo!!", "Segui asi!!", "Muy bien!!", "Excelente!", "Maravilloso!!"]

#definimos variables
x = None
y = None
bordesIzquierda = False
bordesArriba = False
bordesDerecha = False
bordesAbajo = False
puntos = 0
tiempo = 0
modoOrganico = False
terminado = False
cerrar = False
modopuntos = False
modotiempo = False
numPuntos = 1000
cantTiempo = 30
ganar = False
perder = False
modoJuego = None
contaminacion = 0
robot = robotin1
musica = True
sonidos = True


#funcion para resetear variables

def resetVariables():
    global x, y, charco_imagen, bordesIzquierda, bordesArriba, bordesDerecha, bordesAbajo, puntos, modoOrganico, terminado, cerrar, modopuntos, modotiempo, numPuntos, cantTiempo, ganar, perder, tiempo, contaminacion 
    x = None
    y = None
    modoJuego = None
    bordesIzquierda = False
    bordesArriba = False
    bordesDerecha = False
    bordesAbajo = False
    puntos = 0
    tiempo = 0
    terminado = False
    cerrar = False
    modopuntos = False
    modotiempo = False
    ganar = False
    perder = False
    modoJuego = None
    contaminacion = 0

#le damos valor a la matriz
m = []
m = [["" for x in range(8)]  for y in range(5)]

## Aca creamos la funcion que permite al juego tener musica.
def suenaMusica():
    if not pygame.mixer.music.get_busy():
        pygame.mixer.music.play(loops=-1)

#creamos la funcion para agarrar basuras

def colision(n):
    global x, y, m, puntos, numPuntos, puntos_mostrar
    haycolision = False


#utilizamos la matriz para evaluar la posicion de las basuras
    
    if x-int(m[n][2]) < 20 and x-int(m[n][2]) > -128 and y-int(m[n][3]) < 20 and y-int(m[n][3]) > -128:
        m[n][0] = False
        puntos_mostrar = numPuntos - puntos
        haycolision = True
    return haycolision


#utilizamos la matriz para generar las 5 basuras       

def seteaBasura(n):
    global lata, organico, otros, vidrio, toxico, papel, modoOrganico
    m[n][0] = True
    
#les generamos imagen aleatoria, (si es organico entonces siempre es un organico)
    if not modoOrganico:
        asdf = randint(1, 100)
        if asdf<=32:
            m[n][1] = 1
            m[n][6] = otros
            m[n][7] = 10
        elif asdf<=57:
            m[n][1] = 2
            m[n][6] = papel
            m[n][7] = 30
        elif asdf<=78:
            m[n][1] = 3
            m[n][6] = lata
            m[n][7] = 50
        elif asdf<=93:
            m[n][1] = 4
            m[n][6] = vidrio
            m[n][7] = 75
        elif asdf<=98:
            m[n][1] = 5
            m[n][6] = toxico
            m[n][7] = 150
        else:
            m[n][1] = 6
            m[n][6] = organico
            m[n][7] = 200
    else:
        m[n][1] = 6
        m[n][6] = organico
        m[n][7] = 200
##    Le damos velocidad, angulo, etc.
    m[n][2] = 50
    m[n][3] = randint(100,670)
    a = randint(-60, 60)
    a = a*2*math.pi/360
    v = randint(2,3)
    m[n][4] = round(math.cos(a)*v,0)
    m[n][5] = round(math.sin(a)*v,0)



#la funcion que hara aparecer al robot

def funrobotin():
    global x, y, robot
    pantalla.blit(robot,(x,y))
    


#la funcion que hara aparecer al background

def funbackground():
    global display_width, display_height
    pantalla.blit(background, (0, 0))


#la funcion que hara aparecer a las basuras   
def funbasuras(m,n):
    aleatorio = randint(1, 100)
    pantalla.blit(m[n][6],(m[n][2],m[n][3]))
    m[n][0] = True
    
#esto lo utilizaremos mas tarde para insertar textos
def text_objects(text, font):
    textSurface = font.render(text, True, black)
    return textSurface, textSurface.get_rect()

#hacemos la funcion que verifica los highscores
def verificaHighScore():
    global archivosRecords, modoJuego, tiempo, puntos
    if modoJuego == 1 or modoJuego == 3:
        yasa = True
    else:
        yasa = False
    record = open(archivosRecords[modoJuego],"r")
    lista_records = record.readlines()
    record.close()
    i = 0
    es_highscore = False
    if yasa:
        if puntos > int(lista_records[8]) or lista_records[9][:3] == "---":
            es_highscore = True
    else:
        if tiempo < int(lista_records[8]) or lista_records[9][:3] == "---":
            es_highscore = True
    return es_highscore

#para guardar los records
def guardaRecord(b):
    global archivosRecords, modoJuego, puntos, tiempo
    if b == "":
        b = "Usuario"
    if modoJuego == 1 or modoJuego == 3:
        yasa = True
    else:
        yasa = False
    
    record = open(archivosRecords[modoJuego],"r")
    lista_records = record.readlines()
    record.close()
    i = 0
    j = 0
    ya_esta_guardado = False
    while i < 5 and not ya_esta_guardado:
        if yasa:
            if puntos>int(lista_records[2*i]) or lista_records[2*i+1][:3] == "---":
                lista_records.insert(2*i, str(puntos)+"\n")
                lista_records.insert(2*i+1, b + " (" + str(tiempo)+")"+"\n")
                ya_esta_guardado = True
        else:
            if tiempo < int(lista_records[2*i]) or lista_records[2*i+1][:3] == "---":
                lista_records.insert(2*i, str(tiempo)+"\n")
                lista_records.insert(2*i+1, b + " (" + str(puntos)+")"+"\n")
                ya_esta_guardado = True
        i += 1
    if ya_esta_guardado:
        lista_records = lista_records[:len(lista_records)-2]
        record=open(archivosRecords[modoJuego],"w")
        record.writelines(lista_records)
        record.close()
        
#creamos la pantalla de ganar y, si hiciste un record, lo guarda.
def gana():
    input_boxa=pygame.Rect((display_width/2)-200,600,400,50)
    input_box=pygame.Rect((display_width/2)-200,500,400,50)
    pantalla.blit(fondoMenu, (0, 0))    
    largeText= pygame.font.Font('fuente/VintageOne.ttf',185)
    TextSurf, TextRect = text_objects("Ganaste!!", largeText)
    TextRect.center = ((display_width/2),(140))
    pantalla.blit(TextSurf, TextRect)
    botonContinuar=pygame.Rect((display_width/2)-200,500,400,50)
    text = ''
    font = pygame.font.Font(None, 32)
    es_high_score = verificaHighScore()
    while True:
        if not pygame.mixer.music.get_busy() and musica:
            pygame.mixer.music.play()
        pantalla.blit(fondoMenu, (0, 0))
        pantalla.blit(TextSurf, TextRect)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if input_boxa.collidepoint(event.pos):
                    if es_high_score:
                        guardaRecord(text)
                    pantallaMenu()
            if event.type == pygame.KEYDOWN and es_high_score:
                if event.key == pygame.K_BACKSPACE:
                    text = text[:-1]
                elif event.key == pygame.K_RETURN:
                    if es_high_score:
                        guardaRecord(text)
                    pantallaMenu()
                else:
                    text += event.unicode
        if es_high_score:
            mensaje(30, display_width/2, 400, "Introduce tu nombre:")
            txt_surface = font.render(text, True, black)
            pantalla.blit(txt_surface, (input_box.x+5, input_box.y+15))
            pygame.draw.rect(pantalla, black,input_box, 2)
        pygame.draw.rect(pantalla, gris,input_boxa)
        mensaje(30, display_width/2, 620, "Continuar")                    
        pygame.display.update()
        
#y la de perder
def pierde():
    pantalla.blit(fondoMenu, (0, 0))
    largeText= pygame.font.Font('fuente/VintageOne.ttf',185)
    TextSurf, TextRect = text_objects("Perdiste", largeText)
    TextRect.center = ((display_width/2),(140))
    pantalla.blit(TextSurf, TextRect)
    input_box=pygame.Rect((display_width/2)-200,500,400,50)
    while True:
        if not pygame.mixer.music.get_busy() and musica:
            pygame.mixer.music.play()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if input_box.collidepoint(event.pos):
                    pantallaMenu()
        pygame.draw.rect(pantalla, gris,input_box)
        mensaje(30, display_width/2, 520, "Continuar")                    
        pygame.display.update()
    
#creamos la funcion que hace que el juego funcione    
def game_loop():
    global rojo, verde, x, y, felicitaciones, contaminacion, display_width, display_height, m, terminado, cerrar, modopuntos, modotiempo, ganar, perder, numPuntos, cantTiempo, modoOrganico, modoJuego, tiempo, puntos

    #mostramos los mensajes motivadores    
    tiempo_para_mostrar_el_mensaje = -1
    fin_tutorial = False
    if modoOrganico:
        if modopuntos:
            modoJuego = 2
        else:
            modoJuego = 3
    else:
        if modopuntos:
            modoJuego = 0
        else:
            modoJuego = 1
    if modoJuego == 0 or modoJuego == 2:
        imagen_tutorial = pygame.image.load("instrucciones modo puntos.png")
    else:
        imagen_tutorial = pygame.image.load("instrucciones modo tiempo.png")
    while not fin_tutorial:
        pantalla.blit(imagen_tutorial, (0, 0))
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                fin_tutorial = True
        pygame.display.update()
## La musica 8)
    if musica:
        musica_juego = pygame.mixer.music.load("Parov Stelar - All Night (Official Audio).ogg")
        suenaMusica()
    for i in range(5):
        seteaBasura(i)
    x = display_width * 0.45
    y = display_height * 0.45
    x_changeMas = 0
    x_changeMenos = 0
    y_changeMas = 0
    y_changeMenos = 0
    tInicio = time.time()
    hayArea = False
    terminado = False
    area = Zona()
    charco = Zona()
    xa = x
    ya = y

    while not terminado:
        contaminacion = 0
        if not pygame.mixer.music.get_busy() and musica:
            pygame.mixer.music.play()

        tiempo = int(time.time()-tInicio)
        crear_area = randint(1,5)
        if crear_area == 1 and not area.devuelve_existe():
            area.set()
            area.devuelve_posx()
            prohibida_o_bonus = randint(1,5)
            if prohibida_o_bonus == 1:
                es_bonus = True
                es_prohibida = False
            else:
                es_bonus = False
                es_prohibida = True
        crear_charco = randint(1,10)
        if crear_charco == 1 and not charco.devuelve_existe():
            charco.set()
            charco.ajustes_charco(x, y)

#determinamos limites 
        if x > 1100:
            bordesDerecha = True
            x_changeMas = 0
        else:
            bordesDerecha = False
        if x < 91 :
            bordesIzquierda = True
            x_changeMenos = 0
        else:
            bordesIzquierda = False
        if y > 622:
            bordesAbajo = True
            y_changeMas = 0
        else:
            bordesAbajo = False
        if y<77:
            bordesArriba = True
            y_changeMenos = 0
        else:
            bordesArriba = False
        if not charco.colision_con_charco(x, y):
            xa = x
            ya = y
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                cerrar = True
## Le enseñamos al nuestro personaje como se mueve
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT and bordesIzquierda == False: #and not charco.hay_colision_con_charcoxmas(x):
                    x_changeMenos = -5
                elif event.key == pygame.K_RIGHT and bordesDerecha == False: #and not charco.hay_colision_con_charcoxmenos(x):
                    x_changeMas = 5
                if event.key == pygame.K_UP and bordesArriba == False: #and not charco.hay_colision_con_charcoymas(y):
                    y_changeMenos = -5
                if event.key == pygame.K_DOWN and bordesAbajo == False: #and not charco.hay_colision_con_charcoymenos(y):
                    y_changeMas = 5
                if event.key == pygame.K_ESCAPE:
                    pygame.quit()
## Hacemos que se pueda mantener apretada la tecla para moverse de forma continua   
            if event.type == pygame.KEYUP:
                if event.key == pygame.K_LEFT:
                    x_changeMenos = 0
                if event.key == pygame.K_RIGHT:
                    x_changeMas = 0
                if event.key == pygame.K_UP:
                    y_changeMenos = 0
                if event.key == pygame.K_DOWN:
                    y_changeMas = 0

        if charco.colision_con_charco(x, y):
            if charco.hay_colision_con_charcoxmas(x):
##                print("no mueve derecha")
                x_changeMas = 0
                x = xa
            if charco.hay_colision_con_charcoxmenos(x):
    ##            print("no mueve izquierda")
                x_changeMenos = 0
                x = xa
            if charco.hay_colision_con_charcoymas(y):
    ##            print("no mueve abajo")
                y_changeMas = 0
                y = ya
            if charco.hay_colision_con_charcoymenos(y):
    ##            print(" no mueve arriba")
                y_changeMenos = 0
                y = ya
                

                
        x+= x_changeMas
        x+= x_changeMenos
        y+= y_changeMas
        y+= y_changeMenos



        funbackground()
        if charco.devuelve_existe():
            if charco.verificaTiempo():
                charco.desaparece()
        if area.devuelve_existe():
            if area.verificaTiempo():
                area.desaparece()
                es_prohibida = False
                es_bonus = False
        if charco.devuelve_existe():         
            pantalla.blit(charco_imagen, (charco.devuelve_posx(), charco.devuelve_posy()))
        if area.devuelve_existe():
            if es_bonus:
                pygame.draw.rect(pantalla, verde, area.devuelve_borde(), 4)
            else:
                pygame.draw.rect(pantalla, rojo, area.devuelve_borde(), 4)
        funrobotin()
        
        for i in range(5):
            c = False
            d = False
            a = colision(i)
            if a:
                if area.devuelve_existe():
                    if area.colision_con_robotin(m[i][2], m[i][3]):
                        if es_bonus:
                            puntos+=2*int(m[i][7])
                            d = True
                        elif modoJuego == 1 or modoJuego == 3:
                            puntos -= int(m[i][7])
                            if puntos < 0:
                                puntos = 0
                    else:
                        puntos+=int(m[i][7])
                        d = True
                else:
                    puntos+=int(m[i][7])
                    d = True
                
            if m[i][1] == 2 or m[i][1] == 3 or m[i][1] == 4:
                c = True
            if c and d:
                b = True
            else:
                b = False
            if a and b:
                tiempo_para_mostrar_el_mensaje = tiempo+3
                num = randint(0,4)

                
        if tiempo_para_mostrar_el_mensaje >= tiempo:
            mensaje(20, x+64, y-20, felicitacion[num])
        for i in range(5):
            if m[i][0]:
                m[i][2]+=m[i][4]
                m[i][3]+=m[i][5]
                if m[i][3] >= 670 or m[i][3]<=77: 
                    m[i][5] = m[i][5]*-1
                if m[i][2]<=20:
                    m[i][4] = m[i][4]*-1
                if m[i][2] == 1358:
                    contaminacion += 25
                    m[i][0] = False
                if m[i][0]:
                    funbasuras(m,i)
            else:
                seteaBasura(i)
## los mensajes que apareceran ingame
        if modoJuego == 0 or modoJuego ==2:    
            mensaje(40, 200, 40, "Tiempo: "+str(tiempo))
            mensaje(40, 620, 40, "Puntos restantes: "+str(numPuntos-puntos))
            mensaje(40, 1100, 40, "Contaminacion: "+str(contaminacion)+"%")
        else:
            mensaje(40, 300, 40, "Tiempo restante: "+str(cantTiempo-tiempo))
            mensaje(40, 620, 40, "Puntos: "+str(puntos))
            mensaje(40, 1000, 40, "Contaminacion: "+str(contaminacion)+"%")


        pygame.display.update()
        reloj.tick(60)

        if modopuntos:
            if puntos>=numPuntos:
                ganar=True
        else:
            if tiempo >= cantTiempo:
                ganar=True
        if ganar or perder:
            terminado= True
        if cerrar:
            terminado = True
            pygame.quit()
        if contaminacion >= 100:
            perder = True
            ganar = False
            terminado= True
            
    if ganar:
        audio_menu = pygame.mixer.music.load("Undertale OST_ 043 - Temmie Village.ogg")
        if musica:
            suenaMusica()
        gana()
    if perder:
        audio_menu = pygame.mixer.music.load("Undertale OST_ 043 - Temmie Village.ogg")
        if musica:
            suenaMusica()
        pierde()
        
#la funcion para insertar textos
def mensaje(a, b, c, d):
    largeText= pygame.font.Font('fuente/Life is goofy.ttf',a)
    TextSurf, TextRect = text_objects(d, largeText)
    TextRect.center = (b,c)
    pantalla.blit(TextSurf, TextRect)
    
#definimos el "boton jugar" del menu
def botonjugar():
    global modopuntos, modotiempo, gris
    pantalla.blit(fondoMenu, (0, 0))
    color = gris
    input_boxa=[]
    textoBotones=["Modo Tiempo", "Modo Puntos", "Volver"]
    largeText= pygame.font.Font('fuente/orange juice 2.0.ttf',185)
    TextSurf, TextRect = text_objects("Reciclatron", largeText)
    TextRect.center = ((display_width/2),(140))
    pantalla.blit(TextSurf, TextRect)
    for i in range(3):
        input_boxa.append(pygame.Rect((display_width/2-150),360+100*i,300,50))
    text = ''
    done = False
    pygame.display.update()
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if input_boxa[0].collidepoint(event.pos):
                    modotiempo =True
                    modopuntos = False
                    game_loop()
                elif input_boxa[1].collidepoint(event.pos):
                    modopuntos=True
                    modotiempo = False
                    game_loop()
                elif input_boxa[2].collidepoint(event.pos):
                    pantallaMenu()
        for i in range(3):
            pygame.draw.rect(pantalla, color,input_boxa[i])
            mensaje(30, display_width/2, 380+100*i, textoBotones[i]) 
        pygame.display.update()
        
#abre el archivo de record elegido y lo muestra
def muestraRecords(a):
    input_box=pygame.Rect((display_width/2)-200,500,400,50)
    record=open(a,"r")
    lista_a_mostrar = record.readlines()
    record.close()
    pantalla.blit(fondoMenu, (0, 0))
    for i in range(10):
        if i % 2 == 0:
            mensaje(30, display_width/2-100, 200+25*i, lista_a_mostrar[i])
        else:
            mensaje(30, display_width/2+100, 200+25*(i-1), lista_a_mostrar[i])

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if input_box.collidepoint(event.pos):
                    botonRecords()
        pygame.draw.rect(pantalla, gris,input_box)
        mensaje(30, display_width/2, 520, "Volver")                    
        pygame.display.update()






#la pantalla para seleccionar el robot con el que quieras jugar

def seleccionRobot():
    global gris, robotin1, robot, rojo
    
    pantalla.blit(fondoMenu, (0, 0))
    mensaje(120, (display_width/2), 120, "Selecciona tu robot")
    botonRobot = []
    cuadradoSeleccionado = pygame.Rect(0,398,130,130)
    botonVolver = pygame.Rect((display_width/2)-200,580,400,50)
    for i in range(5):
        botonRobot.append(pygame.Rect(120*i+120+128*i, 400, 128, 128))
    while True:
        if robot == robotin1:
            cuadradoSeleccionado.x = 118
        elif robot == robotin2:
            cuadradoSeleccionado.x = 366
        elif robot == robotin3:
            cuadradoSeleccionado.x = 614
        elif robot == robotin4:
            cuadradoSeleccionado.x = 862
        elif robot == robotin5:
            cuadradoSeleccionado.x = 1110
        
        pantalla.blit(fondoMenu, (0, 0))
        mensaje(120, (display_width/2), 120, "Selecciona tu robot")        
        pygame.draw.rect(pantalla, gris, botonVolver)
        mensaje(40, display_width/2, 600, "Volver")
        pantalla.blit(robotin1, (120, 400))
        pantalla.blit(robotin2, (368, 400))
        pantalla.blit(robotin3, (616, 400))
        pantalla.blit(robotin4, (864, 400))
        pantalla.blit(robotin5, (1112, 400))
        pygame.draw.rect(pantalla, rojo, cuadradoSeleccionado, 2)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if botonRobot[0].collidepoint(event.pos):
                    robot = robotin1
                elif botonRobot[1].collidepoint(event.pos):
                    robot = robotin2
                elif botonRobot[2].collidepoint(event.pos):
                    robot = robotin3
                elif botonRobot[3].collidepoint(event.pos):
                    robot = robotin4
                elif botonRobot[4].collidepoint(event.pos):
                    robot = robotin5
                elif botonVolver.collidepoint(event.pos):
                    botonOpciones()
        pygame.display.update()  






        
        
#el menu de opciones, aca se puede activar el modo organico, elegir el personaje, decir con cuantos puntos se gana o con cuanto tiempo se gana.    
def botonOpciones():
    global black, gris, modoOrganico, cantTiempo, numPuntos, musica, sonidos
    auxt = str(cantTiempo)
    auxp = str(numPuntos)
    font = pygame.font.Font(None, 32)
    pantalla.blit(fondoMenu, (0, 0))
    botonPuntosActivo = False
    botonTiempoActivo = False
    largeText= pygame.font.Font('fuente/VintageOne.ttf',70)
    TextSurf, TextRect = text_objects("Opciones", largeText)
    TextRect.center = ((display_width/2),(80))
    pantalla.blit(TextSurf, TextRect)
    botonOrganico = pygame.Rect(330,205,28,28)
    botonPuntos = pygame.Rect(592, 264,216,50)
    botonTiempo = pygame.Rect(592, 319,216,50)
    botonSeleccionRobot = pygame.Rect(20, 500,587,42)
    botonVolver = pygame.Rect((display_width/2)-200,580,400,50)
    botonMusica = pygame.Rect(96, 386, 28, 28)
    while True:
        pantalla.blit(fondoMenu, (0, 0))
        pantalla.blit(TextSurf, TextRect)
        pygame.draw.rect(pantalla, black, botonOrganico, 2)
        pygame.draw.rect(pantalla, black, botonMusica, 2)
        pygame.draw.rect(pantalla, gris, botonSeleccionRobot)
        pygame.draw.rect(pantalla, gris, botonVolver)
        mensaje(40, 98, 100+ 120, "Modo Organico")
        if modoOrganico:
            mensaje(40, 344, 219, "X")
        mensaje(40, 50, 400, "Musica")
        if musica:
            mensaje(40, 110, 400, "X")
        mensaje(40, 170, 100+180, "Puntos para el modo puntos: ")
        mensaje(40, 250, 100+240, "Tiempo para el modo tiempo (en segundos): ")
        mensaje(40, 315, 100+420, "Seleccion de robot (click aqui)")
        mensaje(40, display_width/2, 600, "Volver")
        for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if botonOrganico.collidepoint(event.pos):
                        modoOrganico = not modoOrganico
                    if botonPuntos.collidepoint(event.pos):
                        botonPuntosActivo = True
                        botonTiempoActivo = False
                    if botonTiempo.collidepoint(event.pos):
                        botonPuntosActivo = False
                        botonTiempoActivo = True
                    if botonSeleccionRobot.collidepoint(event.pos):
                        if int(auxp)>0 and int(auxt)>0:
                            numPuntos = int(auxp)
                            cantTiempo = int(auxt)
                            seleccionRobot()
                    if botonVolver.collidepoint(event.pos):
                        if int(auxp)>0 and int(auxt)>0:
                            numPuntos = int(auxp)
                            cantTiempo = int(auxt)
                            pantallaMenu()
                    if botonMusica.collidepoint(event.pos):
                        musica = not musica
                        if musica:
                            suenaMusica()
                        else:
                            pygame.mixer.music.stop()
                if event.type == pygame.KEYDOWN and botonPuntosActivo:
                    if event.key == pygame.K_BACKSPACE:
                        auxp = auxp[:-1]
                    else:
                        if event.unicode == "0" or event.unicode == "1" or event.unicode == "2" or event.unicode == "3" or event.unicode == "4" or event.unicode == "5" or event.unicode == "6" or event.unicode == "7" or event.unicode == "8" or event.unicode == "9":
                            auxp += event.unicode
                            if auxp[0] == "0":
                                auxp = auxp[1:]
                            elif int(auxp) > 9999:
                                auxp = "9999"
                if event.type == pygame.KEYDOWN and botonTiempoActivo:
                    if event.key == pygame.K_BACKSPACE:
                        auxt = auxt[:-1]
                    else:
                        if event.unicode == "0" or event.unicode == "1" or event.unicode == "2" or event.unicode == "3" or event.unicode == "4" or event.unicode == "5" or event.unicode == "6" or event.unicode == "7" or event.unicode == "8" or event.unicode == "9":
                            auxt += event.unicode
                            if auxt[0] == "0":
                                auxt = auxt[1:]
                            elif int(auxt) > 999:
                                auxt = "999"
                    


        textoTiempo = font.render(auxt, True, black)
        textoPuntos = font.render(auxp, True, black)
        botonTiempo.w = max(200, textoTiempo.get_width()+10)
        botonPuntos.w = max(200, textoPuntos.get_width()+10)
        pantalla.blit(textoTiempo, (botonTiempo.x+5, botonTiempo.y+5))
        pantalla.blit(textoPuntos, (botonPuntos.x+5, botonPuntos.y+5))
        pygame.draw.rect(pantalla, black, botonPuntos, 2)
        pygame.draw.rect(pantalla, black, botonTiempo, 2)
        pygame.display.update()                

    
#el boton que abre los records    
def botonRecords():
    color = gris
    a = ""
    pantalla.blit(fondoMenu, (0, 0))
    input_box=[]
    textoBotones=["Por puntos", "Por tiempo", "Por puntos (organico)", "Por tiempo (organico)", "Volver"]
    largeText= pygame.font.Font('fuente/VintageOne.ttf',185)
    TextSurf, TextRect = text_objects("Records", largeText)
    TextRect.center = ((display_width/2),(140))
    pantalla.blit(TextSurf, TextRect)
    for i in range(4):
        x = 1 if i%2 == 0 else -1
        input_box.append(pygame.Rect((display_width/2+250*x)-200,360+100*int(i/2),400,50))
    input_box.append(pygame.Rect((display_width/2)-200,560,400,50))
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if input_box[0].collidepoint(event.pos):
                    a = archivosRecords[0]
                    muestraRecords(a)
                elif input_box[1].collidepoint(event.pos):
                    a = archivosRecords[1]
                    muestraRecords(a)
                elif input_box[2].collidepoint(event.pos):
                    a = archivosRecords[2]
                    muestraRecords(a)
                elif input_box[3].collidepoint(event.pos):
                    a = archivosRecords[3]
                    muestraRecords(a)
                elif input_box[4].collidepoint(event.pos):
                    pantallaMenu()
                    


        for i in range(4):
            xa = 1 if i%2 == 0 else -1
            pygame.draw.rect(pantalla, color,input_box[i])
            mensaje(30, display_width/2+250*xa, 380+100*int(i/2), textoBotones[i])
        pygame.draw.rect(pantalla, color,input_box[4])
        mensaje(30, display_width/2, 580, textoBotones[4])
        pygame.display.update()
        
#definimos la funcion que inicia el menu
def pantallaMenu():
    record=open("Records Puntos.txt","r")
    lista_a_mostrar = record.readlines()
    record.close()
    resetVariables()
    color = gris
    pantalla.blit(fondoMenu, (0, 0))
    for i in range(10):
        if i % 2 == 0:
            mensaje(30, 50, 200+25*i, lista_a_mostrar[i])
        else:
            mensaje(30, 50+100, 200+25*(i-1), lista_a_mostrar[i])
    input_box=[]
    textoBotones=["Jugar", "Opciones", "Records", "Salir"]
    largeText= pygame.font.Font('fuente/orange juice 2.0.ttf',185)
    TextSurf, TextRect = text_objects("Reciclatron", largeText)
    TextRect.center = ((display_width/2),(150))
    pantalla.blit(TextSurf, TextRect)
    for i in range(4):
        input_box.append(pygame.Rect((display_width/2-150),360+100*i,300,50))
    text = ''
    done = False

    while True:
        if not pygame.mixer.music.get_busy() and musica:
            pygame.mixer.music.play()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if input_box[0].collidepoint(event.pos):
                    botonjugar()
                elif input_box[1].collidepoint(event.pos):
                    botonOpciones()
                elif input_box[2].collidepoint(event.pos):
                    botonRecords()
                elif input_box[3].collidepoint(event.pos):
                    pygame.quit()

        for i in range(4):
            pygame.draw.rect(pantalla, color,input_box[i])
            mensaje(30, display_width/2, 380+100*i, textoBotones[i]) 
        pygame.display.update()
suenaMusica()
pantallaMenu()
pygame.quit()
#Esperamos que lo disfruten! :D
