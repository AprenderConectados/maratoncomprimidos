#!/usr/bin/env python
#-*- coding: utf-8 -*-

#Cargamos las librerías necesarias
import turtle
import random
import math

#Se realizan funciones de apoyo para que el main.py con nombres bien representativos
def dibujarElementosDinamicos(basura, jugador, cronometro, tiempoActual, puntuador, puntosActuales, modoDeJuego, modo):
  estiloVariable = ("verdana", 16, "bold")
  estiloModos = ("Comic Sans SM", 18, "bold")

  if tiempoActual >= 0:
    cronometro.write(tiempoActual, font=estiloVariable)
  puntuador.write(puntosActuales, font=estiloVariable)
  if modoDeJuego == 'porTiempo':
    modo.write('Juego por Tiempo', font=estiloModos)
  if modoDeJuego == 'porPuntos':
    modo.write('Juego por Puntos', font=estiloModos)
  if modoDeJuego == 'modOrganico':
    modo.write('Juego en modo Orgánico', font=estiloModos)
  basura.showturtle()
  jugador.showturtle()

#se marcan zonas prohibidas y permitidas 
def marcarZonas(zona):
  estiloZona = ("verdana", 11)
  
  #zona prohibida
  zona.goto(100,-250)
  for i in range(2):
    zona.pendown()
    zona.forward(150)
    zona.left(90)
    zona.forward(500)
    zona.left(90)
  zona.penup()

  #zona prohibida
  zona.goto(-100,250)
  for i in range(2):
    zona.pendown()
    zona.right(90)
    zona.forward(500)
    zona.right(90)
    zona.forward(150)
  
  zona.penup()

def moverBasura(basura, patronMovimiento):
  basura.penup()
  
  if (patronMovimiento == 'linea'):
    basura.forward(0.7)

  if (patronMovimiento == 'aleatorio'):
    basura.right(random.randint(-180,180))
    basura.forward(25)
    basura.setx(basura.xcor()+random.randint(-20,20))
    basura.sety(basura.ycor()+random.randint(-20,20))

  if (patronMovimiento=='aleatorio2'):
    basura.left(random.randint(-180,180))
    basura.backward(30)
    basura.setx(basura.xcor()+random.randint(-20,20))
    basura.sety(basura.ycor()+random.randint(-20,20))

  if (patronMovimiento=='aleatorio3'):
    basura.left(random.randint(-180,180))
    basura.setx(basura.xcor()+random.randint(-20,20))
    basura.sety(basura.ycor()+random.randint(-20,20))
    
  if (patronMovimiento=='lineaRetroceder'):
    basura.backward(0.5)

  return basura

def obtenerBasura():
  imgs = ["ramaorganica.gif", "bananaorganica.gif", "naranjaorganica.gif", "huevoorganico.gif", "manzanaorganica.gif", "botellavidrio.gif","lata.gif", "televisorotros.gif", "radiootros.gif", "papel.gif", "toxico.gif"]
  imgActual = random.choice(imgs)
  basura = turtle.Turtle()
  basura.hideturtle()
  basura.shape(imgActual)
  basura.penup()
  basura.goto(random.randint(-180,180),random.randint(-180,180)) 
  return basura
  
def obtenerJugador():
  jugador = turtle.Turtle()
  jugador.shape("robot.gif")
  jugador.penup()
  jugador.setx(155)
  jugador.sety(0)
  return jugador

def obtenerObstaculo ():
  obstaculo = turtle.Turtle()
  obstaculo.shape("tronco.gif")
  obstaculo.penup()
  obstaculo.setx(0)
  obstaculo.sety(0)
  return obstaculo

def obtenerCronometro():
  tiempoRestante = turtle.Turtle()
  tiempoRestante.penup()
  tiempoRestante.hideturtle()
  tiempoRestante.setx(-270)
  tiempoRestante.sety(200)
  return tiempoRestante
  
def obtenerPuntuador():
  puntuador = turtle.Turtle()
  puntuador.penup()
  puntuador.hideturtle()
  puntuador.setx(-270)
  puntuador.sety(175)
  return puntuador
  
def obtenerTxtTiempoRestante():
  txtTiempoRestante = turtle.Turtle()
  txtTiempoRestante.penup()
  txtTiempoRestante.hideturtle()
  txtTiempoRestante.setx(-390)
  txtTiempoRestante.sety(200)
  return txtTiempoRestante 
  
def obtenerTxtPuntos():
  txtPuntos = turtle.Turtle()
  txtPuntos.penup()
  txtPuntos.hideturtle()
  txtPuntos.setx(-390)
  txtPuntos.sety(175)
  return txtPuntos   

def obtenerTxtModo():
  txtModo = turtle.Turtle()
  txtModo.penup()
  txtModo.hideturtle()
  txtModo.setx(-390)
  txtModo.sety(235)
  return txtModo   

def obtenerTxtMensaje():
  txtMensaje = turtle.Turtle()
  txtMensaje.hideturtle()
  txtMensaje.speed(0)
  txtMensaje.penup()
  txtMensaje.setx(-370)
  txtMensaje.sety(25)
  txtMensaje.color("purple")
  return txtMensaje

def reubicarBasuraSiSeVa(bas):
    x = bas.xcor()
    y = bas.ycor()
    
    if x > 170:
      bas.setx(170)
    elif x < -170:
      bas.setx(-170)
    if y > 150:
      bas.sety(150)
    elif y < -150:
      bas.sety(-150)
    return bas

def reubicarJugadorSiSeVa(jug):
    x = jug.xcor()
    y = jug.ycor()
    
    if x > 250:
      jug.setx(250)
    elif x < -250:
      jug.setx(-250)
  
    if y > 150:
      jug.sety(150)
    elif y < -165:
      jug.sety(-165)
    return jug
#Este es el código que se supone que haga que no choque con el tronco 
def reubicarJugadorSiChocaObstaculo(jug):
    x = jug.xcor()
    y = jug.ycor()
    
    if x > 250:
      jug.setx(250)
    elif x < -250:
      jug.setx(-250)
  
    if y > 150:
      jug.sety(150)
    elif y < -165:
      jug.sety(-165)
    return jug

def colisionan(obj, jugador, umbral):
  d = math.sqrt(math.pow(obj.xcor()-jugador.xcor(),2)+math.pow(obj.ycor()-jugador.ycor(),2))
  if d < umbral:
    return True
  else:
    return False

def obtenerTxtInstrucciones():
  txtInstrucciones = turtle.Turtle()
  txtInstrucciones.hideturtle()
  txtInstrucciones.speed(0)
  txtInstrucciones.penup()
  txtInstrucciones.setx(-270)
  txtInstrucciones.sety(50)
  txtInstrucciones.right(90)
  return txtInstrucciones

def mostrarOpcionesMenu(txtInstrucciones):
  estiloTitulo = ("DK Jambo", 24, "bold italic")
  estiloMenuOpciones = ("JHM Typewriter", 10, "bold italic")
  estiloTituloMenu = ("DK Jambo", 20, "bold italic")
  estiloInstruccion = ("JMH Typewriter", 12, "bold italic")
  
  txtInstrucciones.forward(-150)
  txtInstrucciones.color("purple")
  txtInstrucciones.write('Juego "Reciclemos Juntos"',  font=estiloTitulo)
  txtInstrucciones.forward(60)
  txtInstrucciones.color("cadetblue")
  txtInstrucciones.write("Mueve el robot con las flechas para recolectar los residuos", font=estiloInstruccion)
  txtInstrucciones.color("purple")
  txtInstrucciones.forward(55)
  txtInstrucciones.write("Menú", font=estiloTituloMenu)
  txtInstrucciones.forward(30)
  txtInstrucciones.color("cadetblue")
  txtInstrucciones.write("c - Configuración del juego", font=estiloMenuOpciones)
  txtInstrucciones.forward(30)
  txtInstrucciones.write("o - Empezar juego en modo orgánico", font=estiloMenuOpciones)  
  txtInstrucciones.forward(30)
  txtInstrucciones.write("p - Empezar juego por puntos", font=estiloMenuOpciones)
  txtInstrucciones.forward(30)
  txtInstrucciones.write("t - Empezar juego por tiempo", font=estiloMenuOpciones)
  txtInstrucciones.forward(30)
  txtInstrucciones.write("q - Salir del juego y volver al menú", font=estiloMenuOpciones)
  txtInstrucciones.forward(30)
  txtInstrucciones.write("s - Finalizar juego", font=estiloMenuOpciones)

# retorna residuo orgánico
def obtenerBasuraOrganica():
  imgs = ["ramaorganica.gif", "bananaorganica.gif", "naranjaorganica.gif", "huevoorganico.gif", "manzanaorganica.gif"]
  imgActualOrg = random.choice(imgs)
  basuraOrg = turtle.Turtle()
  basuraOrg.hideturtle()
  basuraOrg.shape(imgActualOrg)
  basuraOrg.penup()
  basuraOrg.goto(random.randint(-180,180),random.randint(-180,180)) 
  return basuraOrg

# retorna texto que se va a guardar en archivo .txt
def guardarArchivo(modoDeJuego, nombreJugador, tiempoRestante, puntosActuales):
    if modoDeJuego == "porPuntos":
      texto = "Modo de Juego: " + modoDeJuego + "\nJugador: " + nombreJugador + "-> Tiempo: " + str(tiempoRestante) + "\n\n"
    if modoDeJuego == "porTiempo":
      texto = "Modo de Juego: " + modoDeJuego + "\nJugador: " + nombreJugador + "-> Puntos: " + str(puntosActuales) + "\n\n"
    return texto  

listaPuntos = []
listaTiempo = []

# se añaden los tiempos y los puntos en listas
def guardarLista(modoDeJuego, nombreJugador, tiempoRestante, puntosActuales):
  global listaPuntos, listaTiempo
  
  if modoDeJuego == "porPuntos":
    listaTiempo.append(tiempoRestante)
  if modoDeJuego == "porTiempo":
    listaPuntos.append(puntosActuales)
  return listaPuntos,listaTiempo

def obtenerTxtRanking():
  txtRanking = turtle.Turtle()
  txtRanking.hideturtle()
  txtRanking.speed(0)
  txtRanking.penup()
  txtRanking.right(90)
  txtRanking.color("SpringGreen")
  return txtRanking

def mostrarRanking(txtRanking,listaTiempo, listaPuntos):
  estiloMenuOpciones = ("verdana", 9)
  estiloTituloMenu = ("Comic Sans MS", 11, "bold")
  
  listaPtos = []
  listaTpos = []

  # se ordenan los items de la lista  
  listaTiempo = sorted(listaTiempo)
  # se invierte el orden de los items de la lista
  listaTiempo.reverse()
  
  txtRanking.goto(-270,-150)
  txtRanking.write("Ranking: Modo por Tiempo", font = estiloTituloMenu)
  txtRanking.forward(20)

  # se añaden items a la lista listaTpos para obtener la lista con 5 elementos
  tiempo = 0
  while (tiempo<len(listaTiempo) and len(listaTiempo)>0 and len(listaTpos)<5):
    listaTpos.append(listaTiempo[tiempo])
    tiempo += 1

  # se muestran los items de la lista
  if len(listaTpos)>0:
    for tpo in range(len(listaTpos)):
      txtRanking.write("Jug1: "+ str(listaTpos[tpo]), font = estiloMenuOpciones)
      txtRanking.forward(20)
  else:
    txtRanking.write("Modo no jugado", font = estiloMenuOpciones)
  
  listaPuntos = sorted(listaPuntos)

  txtRanking.goto(50,-150)
  txtRanking.write("Ranking: Modo por Puntos", font=estiloTituloMenu)
  txtRanking.forward(20)

  punto = 0
  while (punto<len(listaPuntos) and len(listaPuntos)>0 and len(listaPtos)<5):
    listaPtos.append(listaPuntos[punto])
    punto += 1

  if len(listaPtos)>0:
    for pto in range(len(listaPtos)):
      txtRanking.write("Jug1: "+ str(listaPtos[pto]), font = estiloMenuOpciones)
      txtRanking.forward(20)
  else:
    txtRanking.write("Modo no jugado", font = estiloMenuOpciones)

def obtenerLinea():
  linea = turtle.Turtle()
  linea.penup()
  linea.speed(0)
  linea.hideturtle()
  linea.color("red")
  return linea
