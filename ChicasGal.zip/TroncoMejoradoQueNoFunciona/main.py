#!/usr/bin/env python
#-*- coding: utf-8 -*-

#IDLE
#Python 2.7

#Cargamos las librerias necesarias
import turtle
from funciones import *
import time

#Cargamos los recursos de imagenes. 
screen = turtle.Screen()
screen.setup(800,550)
screen.title("Reciclemos juntos")
screen.bgcolor("mistyrose")
screen.register_shape("ramaorganica.gif")
screen.register_shape("botellavidrio.gif")
screen.register_shape("lata.gif")
screen.register_shape("televisorotros.gif")
screen.register_shape("papel.gif")
screen.register_shape("toxico.gif")
screen.register_shape("robot.gif")
screen.register_shape("bananaorganica.gif")
screen.register_shape("huevoorganico.gif")
screen.register_shape("manzanaorganica.gif")
screen.register_shape("radiootros.gif")
screen.register_shape("naranjaorganica.gif")
screen.register_shape("tronco.gif")

#Inicializamos variables
puedoConfigurar = True
jugando = False
situada = False
patronMovimiento = 'aleatorio'  
modoDeJuego = 'porTiempo'
global txtInstrucciones
tiempoTotalConfigurado = 15
puntosTotalesConfigurados = 300
nombreJugador = 'Jug1'
tiempoTotal = tiempoTotalConfigurado
puntosTotales = puntosTotalesConfigurados
tiempoActual = 0
puntosActuales = 0
txtRanking = obtenerTxtRanking()

def mostrarMenu():
  global txtInstrucciones, puedoConfigurar
  
  txtInstrucciones = obtenerTxtInstrucciones() 
  mostrarOpcionesMenu(txtInstrucciones)
  puedoConfigurar = True
  screen.update()

mostrarMenu()
jugador = obtenerJugador()

#Definimos al bucle del juego
def loopJuego():
  global jugando, txtInstrucciones, situada, jugador, patronMovimiento, puedoConfigurar, modoDeJuego, tiempoTotal, puntosTotales, puntosActuales, nombreJugador, obtenerObstaculo, reubicarJugadorSiChocaObstaculo
  

  estilo3 = ("Comic Sans MS", 15, "bold")
  estilo5 = ("DK Jambo", 14, "bold")
  listT = []
  listP = []
  txtInstrucciones.clear()
  txtRanking.clear()
  screen = turtle.Screen()
  screen.bgpic("fondo.gif")
  cronometro = obtenerCronometro()
  puntuador = obtenerPuntuador()
  modo = obtenerTxtModo()
  modo.color("white")
  txtTiempoRestante = obtenerTxtTiempoRestante()
  txtTiempoRestante.write('Tiempo: ', font = estilo5)
  txtPuntos = obtenerTxtPuntos()
  txtPuntos.write('Puntos: ', font = estilo5)
  tiempoInicio = int(round(time.time()))
  auxTiempo = int(round(time.time()-tiempoInicio))
  auxPuntos = 0
  txtMensaje = obtenerTxtMensaje()
  tiempoAux = 0
  zona = obtenerLinea()
  obstaculo = obtenerObstaculo()
    
  if (modoDeJuego == 'porTiempo'):
    puntosActuales = 0
    tiempoRestante = tiempoTotalConfigurado
  elif (modoDeJuego == 'porPuntos')or(modoDeJuego == 'modOrganico'):
    puntosActuales = puntosTotalesConfigurados
    puntosRestantes = 0
    tiempoRestante = 0

  if (modoDeJuego == 'porTiempo')or(modoDeJuego == 'porPuntos'):
    bas = obtenerBasura()
  else:
    bas = obtenerBasuraOrganica()
    
  diccionarioPuntaje = {"ramaorganica.gif" : "200", "bananaorganica.gif": "200", "huevoorganico.gif": "200", "manzanaorganica.gif" : "200", "naranjaorganica.gif"  : "200", "televisorotros.gif" : "10", "radiootros.gif" : "10", "toxico.gif" : "150", "botellavidrio.gif" : "75", "lata.gif" : "50", "papel.gif" : "30" }
  marcarZonas(zona)  

  while (jugando == True):
    puedoConfigurar = False
    tiempoRestante = int(round(time.time()-tiempoInicio))
    if (modoDeJuego == 'porTiempo'):
      if not (tiempoRestante == auxTiempo):
        cronometro.clear()
        auxTiempo = tiempoRestante
      tiempoRestante = tiempoTotal-tiempoRestante
    elif (modoDeJuego == 'porPuntos')or(modoDeJuego == 'modOrganico'):
      if not (tiempoRestante == auxTiempo):
        cronometro.clear()
        auxTiempo = tiempoRestante
      auxPuntos = puntosRestantes

    #se aumentan patrones de movimiento
    patrones = ['linea', 'aleatorio', 'aleatorio2', 'aleatorio3', 'lineaRetroceder']
    bas = moverBasura(bas, patronMovimiento)
    
    if (situada == False):
      patronMovimiento = random.choice(patrones)
      situada = True      
    
    bas = moverBasura(bas, patronMovimiento)
    bas = reubicarBasuraSiSeVa(bas)
    jugador = reubicarJugadorSiSeVa(jugador)
    jugador = reubicarJugadorSiChocaObstaculo(jugador)
    num = int(diccionarioPuntaje[bas.shape()])
    
    if (colisionan(jugador, bas, 50) == True):
      situada = False
      bas.hideturtle()
      bas.clear()
      txtMensaje.write('Recolectado!!!', font = estilo3)
      tiempoAux = tiempoRestante
      if (modoDeJuego == 'porTiempo')or(modoDeJuego == 'porPuntos'):
        bas = obtenerBasura()
        obs = obtenerObstaculo()
      else:
        bas = obtenerBasuraOrganica()
        obs = obtenerObstaculo()

      if((modoDeJuego == 'porPuntos')or(modoDeJuego == 'modOrganico')):
        if (jugador.xcor()<100) and (jugador.xcor()>-100):  
          puntosActuales = puntosActuales-num             
        if (puntosActuales <= 0):    
          cronometro.clear()
          puntuador.clear()
          obstaculo.clear()
          jugando = False
      else:
        if (jugador.xcor()<100) and (jugador.xcor()>-100):
          puntosActuales = puntosActuales+num
        else:
          puntosActuales = puntosActuales-num
            
      if not (puntosActuales == auxPuntos):
        puntuador.clear()
        auxPuntos = puntosActuales    
    
    if modoDeJuego == 'porPuntos' or modoDeJuego == 'modOrganico': 
      if tiempoAux+3 == tiempoRestante:
        txtMensaje.hideturtle()
        txtMensaje.clear()
        
    if (modoDeJuego == 'porTiempo'):
      if tiempoAux-3 == tiempoRestante:
        txtMensaje.hideturtle()
        txtMensaje.clear()
      if (tiempoRestante <= 0):
        cronometro.clear()
        jugando = False
          
    dibujarElementosDinamicos(bas, jugador, cronometro, tiempoRestante, puntuador, puntosActuales, modoDeJuego, modo)
    screen.update()

  #Se guarda en el archivo modo de juego, nombre de jugador, tiempo y puntos 
  if modoDeJuego == 'porTiempo' or modoDeJuego == 'porPuntos':
    archi = open('NombresPorModo.txt',"a")
    texto = guardarArchivo(modoDeJuego, nombreJugador, tiempoRestante, puntosActuales)
    archi.write(texto)
    archi.close()
    listT, listP = guardarLista(modoDeJuego, nombreJugador, tiempoRestante, puntosActuales)
    
  #Si el juego esta detenido borramos todo
  jugador.hideturtle()
  jugador.clear()
  txtTiempoRestante.clear()
  txtTiempoRestante.hideturtle()
  txtPuntos.clear()
  txtPuntos.hideturtle()
  puntuador.clear()
  puntuador.hideturtle()
  modo.hideturtle()
  modo.clear()
  cronometro.clear()
  cronometro.hideturtle()
  bas.hideturtle()
  bas.clear()
  txtInstrucciones.hideturtle()
  txtInstrucciones.clear()
  txtMensaje.hideturtle()
  txtMensaje.clear()
  zona.hideturtle()
  zona.clear()
  mostrarRanking(txtRanking, listT, listP)
  mostrarMenu()
  obstaculo.hideturtle()
  obstaculo.clear()
    
#Definimos la operacion de comienzo de juego
def empezarJuego():
  global jugando, puedoConfigurar
  if (jugando == False):
    jugando = True
    loopJuego()

def empezarJuegoModOrganico():
  global modoDeJuego
  modoDeJuego = 'modOrganico'
  empezarJuego()
   
def empezarJuegoPorPuntos():
  global modoDeJuego
  modoDeJuego = 'porPuntos'
  empezarJuego()

def empezarJuegoPorTiempo():
  global modoDeJuego
  modoDeJuego = 'porTiempo'
  empezarJuego()

def volverAlMenu():
  global jugando, puedoConfigurar
  jugando = False
  puedoConfigurar = False
  
def ingresarParametrosDeConfiguracion():
  global tiempoTotal, puntosTotalesConfigurados, puedoConfigurar, jugando, nombreJugador
  
  if (jugando == False):
    if (puedoConfigurar == True):
      puedoConfigurar = False
      tiempoTotal = int(raw_input("Ingrese la cantidad de segundos que dispondrá el jugador para el Modo por Tiempo: "))
      puntosTotalesConfigurados = int(raw_input("Ingrese el puntaje máximo para el Modo Puntos: "))
      
      if not (tiempoTotal > 0):
        tiempoTotal = 10
      if not (puntosTotalesConfigurados > 0):
        puntosTotalesConfigurados = 5
   
#Definimos las funciones de movimiento del jugador
def atras():
  global jugador
  jugador.sety(jugador.ycor()-30)

def adelante():
  global jugador
  jugador.sety(jugador.ycor()+30)

def izquierda():
  global jugador
  jugador.setx(jugador.xcor()-30)

def derecha():
  global jugador
  jugador.setx(jugador.xcor()+30)

def salirDelJuego():
  global jugando
  jugando = False

def finalizarJuego():
  turtle.bye()

#Realizamos codigo que invoca las funciones anteriores segun la tecla que se presione  
turtle.onkey(adelante, "Up")
turtle.onkey(atras, "Down")
turtle.onkey(izquierda, "Left")
turtle.onkey(derecha, "Right")
turtle.onkey(empezarJuegoModOrganico, "o")
turtle.onkey(empezarJuegoPorPuntos, "p")
turtle.onkey(empezarJuegoPorTiempo, "t")
turtle.onkey(ingresarParametrosDeConfiguracion, "c")
turtle.onkey(salirDelJuego, "q")
turtle.onkey(finalizarJuego,"s")
turtle.listen()
turtle.mainloop()


